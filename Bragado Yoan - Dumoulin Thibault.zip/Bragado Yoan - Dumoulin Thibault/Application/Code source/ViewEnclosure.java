package ZooTD;

/**
 * Created by Administrateur on 04/11/2016.
 */
public class ViewEnclosure {

    /**
     * Show carac.
     *
     * @param name        the name
     * @param area        the area
     * @param maxAnimals  the max animals
     * @param nbAnimals   the nb animals
     * @param cleanness   the cleanness
     * @param isCleanable the is cleanable
     */
    public void showCarac(String name, int area, int maxAnimals, int nbAnimals, String cleanness, boolean isCleanable) {
        System.out.println("Les caractéristiques de l'enclos : \n" +
                "\t - Nom : " + name + "\n" +
                "\t - Superficie : " + area + "m²\n" +
                "\t - Nombre maximal d'animaux pour l'enclos : " + maxAnimals + " \n" +
                "\t - Nombre d'animaux présents dans l'enclos : " + nbAnimals + " \n" +
                "\t - Propreté : " + cleanness + "\n" +
                "\t - Netoyable: " + isCleanable + "\n");
    }

    /**
     * Show err carac animals.
     */
    public void showErrCaracAnimals() {
        System.out.println("Les caractéristiques des animaux de l'enclos : Aucun animal présent dans l'enclos");
    }

    /**
     * Show info carac animals.
     */
    public void showInfoCaracAnimals() {
        System.out.println("Les caractéristiques des animaux de l'enclos : \n\n");
    }

    /**
     * Show carac animals.
     *
     * @param name       the name
     * @param sex        the sex
     * @param weight     the weight
     * @param height     the height
     * @param age        the age
     * @param hunger     the hunger
     * @param sleep      the sleep
     * @param health     the health
     * @param isPregnant the is pregnant
     */
    public void showCaracAnimals(String name, char sex, int weight, int height, int age, boolean hunger, boolean sleep, boolean health,
    boolean isPregnant) {
        System.out.println("\t - Nom : " + name + "\n" +
                "\t - Sexe : " + sex + "\n" +
                "\t - Poids : " + weight + "kg\n" +
                "\t - Taille : " + height + "cm\n" +
                "\t - Age : " + age + "\n" +
                "\t - Faim : " + hunger + "\n" +
                "\t - Endormi : " + sleep + "\n" +
                "\t - Santé : " + health);
        if (sex == 'f')
            System.out.println("\t - Enceinte : " + isPregnant + "\n");

        System.out.println("\n \n");
    }

    /**
     * Show err add.
     */
    public void showErrAdd() {
        System.out.println("L'enclos possède deja le nombre maximal d'animaux \n");
    }

    /**
     * Show err add 2.
     */
    public void showErrAdd2() {
        System.out.println("Un enclos standard ne peut pas contenir d'animal marin ou volant \n");
    }

    /**
     * Show add succ.
     */
    public void showAddSucc() {
        System.out.println("L'animal à été rajouté !");
    }

    /**
     * Show err add 3.
     *
     * @param name the name
     */
    public void showErrAdd3(String name) {
        System.out.println("L'animal n'est pas de la meme race que ceux de l'enclos. Il y a des " + name
                + "\n");
    }

    /**
     * Show remove succ.
     */
    public void showRemoveSucc() {
        System.out.println("L'animal à été retiré \n");
    }

    /**
     * Show be cleanable succ.
     */
    public void showBeCleanableSucc() {
        System.out.println("Les animaux sont en cage \n");
    }

    /**
     * Show err be cleanable.
     *
     * @param name the name
     */
    public void showErrBeCleanable(String name) {
        System.out.println("L'enclos n'est pas sale : " + name + "\n");
    }
}
