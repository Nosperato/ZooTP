package ZooTD;

/**
 * Created by d13002386 on 10/10/2016.
 */
public interface AnimalAction {

    /**
     * Eat.
     *
     * @param i the
     */
    public void eat(int i);

    /**
     * Make sound.
     */
    public void makeSound();

    /**
     * Change condition boolean.
     *
     * @return the boolean
     */
    public boolean changeCondition();

    /**
     * Treat.
     */
    public void treat();

    /**
     * Move.
     */
    public void move();

    /**
     * Mate.
     *
     * @param a the a
     */
    public void mate(Animal a);
}
