package ZooTD;

import org.jetbrains.annotations.Contract;

/**
 * Created by Administrateur on 04/11/2016.
 */
public abstract class AbstractAnimalFactocry {

    /**
     * Getter for property 'newAnimal'.
     *
     * @return Value for property 'newAnimal'.
     */
    @Contract(" -> !null")
    public static AnimalFactory getNewAnimal() {
        return new AnimalFactory();
    }
}
