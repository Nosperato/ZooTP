package ZooTD;

/**
 * Created by Administrateur on 04/11/2016.
 */
public class ViewOther {

    /**
     * Show err lay.
     */
    public void showErrLay() {
        System.out.println("un male ne peut pas pondre");
    }

    /**
     * Show err lay 2.
     */
    public void showErrLay2() {
        System.out.println("La durée des gestion n'est pas encore atteinte");
    }

    /**
     * Show move eagle.
     *
     * @param name the name
     */
    public void showMoveEagle(String name) {
        System.out.println("L'" + name + " marche. \n");
    }

    /**
     * Show fly eagle.
     *
     * @param name the name
     */
    public void showFlyEagle(String name) {
        System.out.println("L'" + name + " vole. \n");
    }

    /**
     * Show swim.
     *
     * @param name the name
     */
    public void showSwim(String name) {
        System.out.println("Le " + name + " nage. \n");
    }

    /**
     * Show fly penguin.
     *
     * @param name the name
     */
    public void showFlyPenguin(String name) {
        System.out.println("Le " + name + " vole. \n");
    }

    /**
     * Show swim red fish.
     *
     * @param name the name
     */
    public void showSwimRedFish(String name) {
        System.out.println("Le " + name + " nage. \n");
    }
}
