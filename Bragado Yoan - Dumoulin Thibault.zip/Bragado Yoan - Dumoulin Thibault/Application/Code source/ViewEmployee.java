package ZooTD;

/**
 * Created by Administrateur on 04/11/2016.
 */
public class ViewEmployee {

    /**
     * Show relocate succ.
     */
    public void showRelocateSucc() {
        System.out.println("L'animal à été déplacé dans l'enclos \n");
    }
}

