package ZooTD;

/**
 * Created by Administrateur on 04/11/2016.
 */
public class ViewAnimal {

    /**
     * Show not hungry.
     *
     * @param name the name
     */
    public void showNotHungry(String name) {
        System.out.println("Le " + name + " n'a pas faim \n");
    }

    /**
     * Show eat.
     *
     * @param name the name
     */
    public void showEat(String name) {
        System.out.println("Le " + name + " mange \n");
    }

    /**
     * Show err eat.
     *
     * @param name the name
     */
    public void showErrEat(String name) {
        System.out.println("Le " + name + " dort et donc ne peut pas manger. \n");
    }

    /**
     * Show make soud.
     *
     * @param name the name
     */
    public void showMakeSoud(String name) {
        System.out.println(name + " : *Cris* \n");
    }

    /**
     * Show move.
     *
     * @param name the name
     */
    public void showMove(String name) {
        System.out.println("Le " + name + " vagabonde. \n");
    }

    /**
     * Show treat.
     *
     * @param name the name
     */
    public void showTreat(String name) {
        System.out.println("Le " + name + " est soigné. \n");
    }

    /**
     * Show err treat.
     */
    public void showErrTreat() {
        System.out.println("Santé normale");
    }

    /**
     * Show err mate.
     */
    public void showErrMate() {
        System.out.println("Deux races différentes ne peuvent pas s'accoupler. \n");
    }

    /**
     * Show err mate 1.
     *
     * @param name the name
     */
    public void showErrMate1(String name) {
        System.out.println(name + " est deja en période de gestation.\n");
    }

    /**
     * Show err mate 2.
     */
    public void showErrMate2() {
        System.out.println("Seul un mal et une femelle peuvent s\'accoupler.\n");
    }

    /**
     * Show err mate 3.
     *
     * @param name the name
     */
    public void showErrMate3(String name) {
        System.out.println("Un " + name + " dort.\n");
    }
}
