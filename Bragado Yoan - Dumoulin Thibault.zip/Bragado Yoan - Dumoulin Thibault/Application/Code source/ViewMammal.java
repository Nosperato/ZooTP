package ZooTD;

/**
 * Created by Administrateur on 04/11/2016.
 */
public class ViewMammal {

    /**
     * Show err birth.
     */
    public void showErrBirth() {
        System.out.println("un male ne peut pas accoucher");
    }

    /**
     * Show err birth 2.
     */
    public void showErrBirth2() {
        System.out.println("La durée des gestion n'est pas encore atteinte");
    }

    /**
     * Show swim whale.
     *
     * @param name the name
     */
    public void showSwimWhale(String name) {
        System.out.println("La " + name + " nage. \n");
    }

    /**
     * Show swim shark.
     *
     * @param name the name
     */
    public void showSwimShark(String name) {
        System.out.println("Le " + name + " nage. \n");
    }
}
