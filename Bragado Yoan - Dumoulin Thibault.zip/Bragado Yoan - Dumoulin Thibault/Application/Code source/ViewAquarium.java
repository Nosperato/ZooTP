package ZooTD;

/**
 * Created by Administrateur on 04/11/2016.
 */
public class ViewAquarium extends ViewEnclosure{

    /**
     * Show carac aquarium.
     *
     * @param name        the name
     * @param area        the area
     * @param dept        the dept
     * @param maxAnimals  the max animals
     * @param nbAnimals   the nb animals
     * @param cleanness   the cleanness
     * @param salinity    the salinity
     * @param isCleanable the is cleanable
     */
    public void showCaracAquarium(String name, int area, int dept ,int maxAnimals, int nbAnimals, String cleanness, boolean salinity ,boolean isCleanable) {
        System.out.println("Les caractéristiques de l'enclos : \n" +
                "\t - Nom : " + name + "\n" +
                "\t - Superficie : " + area + "m²\n" +
                "\t - Profondeur : " + dept + "m\n" +
                "\t - Nombre maximal d'animaux pour l'enclos : " + maxAnimals + " \n" +
                "\t - Nombre d'animaux présents dans l'enclos : " + nbAnimals + " \n" +
                "\t - Propreté : " + cleanness + "\n" +
                "\t - Salinité : " + salinity + "\n" +
                "\t - Netoyable: " + isCleanable + "\n");

    }

    /**
     * Show err add 4.
     */
    public void showErrAdd4() {
        System.out.println("Un aquarium ne peut pas contenir d'animal autre que marin \n");
    }

    /**
     * Show err salinity.
     */
    public void showErrSalinity() {
        System.out.println("La salinité n'est pas bonne \n");
    }

    /**
     * Show salinity succ.
     */
    public void showSalinitySucc() {
        System.out.println("La salinité est remise à niveau \n");
    }

    /**
     * Show err dept.
     */
    public void showErrDept() {
        System.out.println("La profondeur n'est pas bonne");
    }

    /**
     * Show dept succ.
     */
    public void showDeptSucc() {
        System.out.println("La profondeur est rétablie.");
    }
}
