package ZooTD;

/**
 * Created by d13002386 on 10/10/2016.
 */
public abstract class Other extends Animal implements OtherAction{

    private ViewOther viewOther;

    /**
     * Getter for property 'viewOther'.
     *
     * @return Value for property 'viewOther'.
     */
    public ViewOther getViewOther() {
        return viewOther;
    }

    /**
     * Setter for property 'viewOther'.
     *
     * @param viewOther Value to set for property 'viewOther'.
     */
    public void setViewOther(ViewOther viewOther) {
        this.viewOther = viewOther;
    }
}
