package ZooTD;

import java.util.ArrayList;

/**
 * Created by Administrateur on 31/10/2016.
 */
//perspective d'amélioration ==> faire ArrayList<Animal> list = new ArrayList<Loup>() exemple
public class Enclosure {

    private String name;
    private int area;
    private final int maxAnimals;
    private int nbAnimals;
    private ArrayList<Animal> animalsList;
    private String cleanness; //sale, correct, bon
    private boolean cleanable;
    private ArrayList<Animal> cages;
    private ViewEnclosure view;


    /**
     * Instantiates a new Enclosure.
     *
     * @param name       the name
     * @param area       the area
     * @param maxAnimals the max animals
     */
    public Enclosure(String name, int area, int maxAnimals) {
        this.name = name;
        this.area = area;
        this.maxAnimals = maxAnimals;
        this.nbAnimals = 0;
        this.animalsList = new ArrayList<>();
        this.animalsList.add(null);
        this.cleanness = "Bon";
        this.cleanable = true;
        this.cages = new ArrayList<>();
        this.view = new ViewEnclosure();
    }

    /**
     * Getter for property 'cleanable'.
     *
     * @return Value for property 'cleanable'.
     */
    public boolean isCleanable() {
        return cleanable;
    }

    /**
     * Setter for property 'cleanable'.
     *
     * @param cleanable Value to set for property 'cleanable'.
     */
    public void setCleanable(boolean cleanable) {
        this.cleanable = cleanable;
    }

    /**
     * Getter for property 'name'.
     *
     * @return Value for property 'name'.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Setter for property 'name'.
     *
     * @param name Value to set for property 'name'.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for property 'area'.
     *
     * @return Value for property 'area'.
     */
    public int getArea() {
        return this.area;
    }

    /**
     * Setter for property 'area'.
     *
     * @param area Value to set for property 'area'.
     */
    public void setArea(int area) {
        this.area = area;
    }

    /**
     * Getter for property 'maxAnimals'.
     *
     * @return Value for property 'maxAnimals'.
     */
    public int getMaxAnimals() {
        return this.maxAnimals;
    }

    /**
     * Getter for property 'nbAnimals'.
     *
     * @return Value for property 'nbAnimals'.
     */
    public int getNbAnimals() {
        return this.nbAnimals;
    }

    /**
     * Setter for property 'nbAnimals'.
     *
     * @param nbAnimals Value to set for property 'nbAnimals'.
     */
    public void setNbAnimals(int nbAnimals) {
        this.nbAnimals = nbAnimals;
    }

    /**
     * Getter for property 'animalsList'.
     *
     * @return Value for property 'animalsList'.
     */
    public ArrayList<Animal> getAnimalsList() {
        return this.animalsList;
    }

    /**
     * Getter for property 'cleanness'.
     *
     * @return Value for property 'cleanness'.
     */
    public String getCleanness() {
        return this.cleanness;
    }

    /**
     * Setter for property 'cleanness'.
     *
     * @param cleanness Value to set for property 'cleanness'.
     */
    public void setCleanness(String cleanness) {
        this.cleanness = cleanness;
    }

    /**
     * Getter for property 'cages'.
     *
     * @return Value for property 'cages'.
     */
    public ArrayList<Animal> getCages() {
        return cages;
    }

    /**
     * Getter for property 'view'.
     *
     * @return Value for property 'view'.
     */
    public ViewEnclosure getView() {
        return view;
    }

    /**
     * Gets caracteristics.
     */
    public void getCaracteristics() {
        this.getView().showCarac(this.getName(), this.getArea(), this.getMaxAnimals(), this.getNbAnimals(), this.getCleanness(), this.isCleanable());
        this.getCaracAnimals(this.getAnimalsList());
    }

    /**
     * Gets carac animals.
     *
     * @param list the list
     */
    public void getCaracAnimals(ArrayList<Animal> list) {
        if(list.get(0) == null)
            this.getView().showErrCaracAnimals();
        else {
            this.getView().showInfoCaracAnimals();
            for (Animal animal : list) {
                this.getView().showCaracAnimals(animal.getName(), animal.getSex(), animal.getWeight(), animal.getHeight(), animal.getAge(),
                        animal.getHungerIndicator(), animal.getSleepIndicator(), animal.getHealthIndicator(), animal.isPregnant());
            }
        }
    }

    /**
     * Add animal.
     *
     * @param animal the animal
     */
    public void addAnimal(Animal animal) {
        if(this.getNbAnimals() == this.getMaxAnimals())
            this.getView().showErrAdd();
        else {
            if (animal instanceof Marine || animal instanceof Flying)
                this.getView().showErrAdd2();
            else {
                if (this.getAnimalsList().get(0) == null) {
                    this.getAnimalsList().remove(0);
                    this.getAnimalsList().add(animal);
                    this.setNbAnimals(this.getNbAnimals() + 1);
                    this.setCleanable(false);
                    this.getView().showAddSucc();
                } else {
                    if (animal.getClass() != this.getAnimalsList().get(0).getClass())
                        this.getView().showErrAdd3(this.getAnimalsList().get(0).getName());
                    else {
                        this.getAnimalsList().add(animal);
                        this.setNbAnimals(this.getNbAnimals() + 1);
                        this.getView().showAddSucc();
                    }
                }
            }
        }
    }

    /**
     * Remove animal.
     */
    public void removeAnimal() {
        if(this.getAnimalsList().size() == 1) {
            this.getAnimalsList().set(0, null);
            this.setCleanable(true);
            this.getView().showRemoveSucc();
        }else {
            this.getAnimalsList().remove(this.getAnimalsList().size() - 1);
            this.getView().showRemoveSucc();
        }
    }

    /**
     * Feed.
     */
    public void feed() {
        for(int i = 0; i < this.getAnimalsList().size(); i++)
            this.getAnimalsList().get(i).eat(i);
    }

    /**
     * Caging.
     *
     * @param enclosure the enclosure
     */
    public static void caging(Enclosure enclosure) {
        for(int i = 0; i < enclosure.getAnimalsList().size(); i++) {
            Animal a = enclosure.getAnimalsList().get(i);
            enclosure.getAnimalsList().remove(i);
            enclosure.getCages().add(a);
        }
        enclosure.setCleanable(true);
    }

    /**
     * Be cleanable.
     */
    public void beCleanable() {
        if(this.getCleanness().equals("sale")) {
            caging(this);
            this.getView().showBeCleanableSucc();
        } else
            this.getView().showErrBeCleanable(this.getName());
    }

    /**
     * Clean.
     */
    public void clean() {
        this.beCleanable();
        this.setCleanness("Bon");
        uncaging(this);
    }

    /**
     * Uncaging.
     *
     * @param enclosure the enclosure
     */
    public static void uncaging(Enclosure enclosure) {
        for(int i = 0; i < enclosure.getCages().size(); i++) {
            Animal a = enclosure.getCages().get(i);
            enclosure.getCages().remove(i);
            enclosure.getAnimalsList().add(a);
        }
        enclosure.setCleanable(false);
    }
}
