package ZooTD;

/**
 * Created by Administrateur on 01/11/2016.
 */
public class Employee {

    private String name;
    private char sex;
    private int age;
    private ViewEmployee view;

    /**
     * Instantiates a new Employee.
     *
     * @param name the name
     * @param sex  the sex
     * @param age  the age
     */
    public Employee(String name, char sex, int age) {
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.view = new ViewEmployee();
    }

    /**
     * Getter for property 'name'.
     *
     * @return Value for property 'name'.
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for property 'name'.
     *
     * @param name Value to set for property 'name'.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for property 'sex'.
     *
     * @return Value for property 'sex'.
     */
    public char getSex() {
        return sex;
    }

    /**
     * Setter for property 'sex'.
     *
     * @param sex Value to set for property 'sex'.
     */
    public void setSex(char sex) {
        this.sex = sex;
    }

    /**
     * Getter for property 'age'.
     *
     * @return Value for property 'age'.
     */
    public int getAge() {
        return age;
    }

    /**
     * Setter for property 'age'.
     *
     * @param age Value to set for property 'age'.
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * Inspect.
     *
     * @param enclosure the enclosure
     */
    public void inspect(Enclosure enclosure) {
        enclosure.getCaracteristics();
    }

    /**
     * Clean.
     *
     * @param enclosure the enclosure
     */
    public void clean(Enclosure enclosure) {
        enclosure.clean();
    }

    /**
     * Feed.
     *
     * @param enclosure the enclosure
     */
    public void feed(Enclosure enclosure) {
        enclosure.feed();
    }

    /**
     * Getter for property 'view'.
     *
     * @return Value for property 'view'.
     */
    public ViewEmployee getView() {
        return view;
    }

    /**
     * Setter for property 'view'.
     *
     * @param view Value to set for property 'view'.
     */
    public void setView(ViewEmployee view) {
        this.view = view;
    }

    /**
     * Relocate.
     *
     * @param enclosure1 the enclosure 1
     * @param enclosure2 the enclosure 2
     */
    public void relocate(Enclosure enclosure1, Enclosure enclosure2) {
        Animal a = enclosure1.getAnimalsList().get(enclosure1.getAnimalsList().size()-1);
        enclosure1.removeAnimal();
        enclosure2.addAnimal(a);
        this.getView().showRelocateSucc();

    }
}
