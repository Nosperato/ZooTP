package ZooTD;


/**
 * The type Animal.
 */
public abstract class Animal implements AnimalAction{

    private String name;
    private char sex;
    private int weight;
    private int height;
    private int age;
    private boolean hungerIndicator;
    private boolean sleepIndicator;
    private boolean healthIndicator;
    private boolean pregnant;
    private int durationGestation;//month
    private int currentDurationGestation;
    private ViewAnimal view = new ViewAnimal();


    /**
     * Setter for property 'pregnant'.
     *
     * @param pregnant Value to set for property 'pregnant'.
     */
    public void setPregnant(boolean pregnant) {
        this.pregnant = pregnant;
    }

    /**
     * Getter for property 'currentDurationGestation'.
     *
     * @return Value for property 'currentDurationGestation'.
     */
    public int getCurrentDurationGestation() {
        return currentDurationGestation;
    }

    /**
     * Getter for property 'durationGestation'.
     *
     * @return Value for property 'durationGestation'.
     */
    public int getDurationGestation() {
        return durationGestation;
    }

    /**
     * Getter for property 'pregnant'.
     *
     * @return Value for property 'pregnant'.
     */
    public boolean isPregnant() {
        return pregnant;
    }

    /**
     * Setter for property 'currentDurationGestation'.
     *
     * @param currentDurationGestation Value to set for property 'currentDurationGestation'.
     */
    public void setCurrentDurationGestation(int currentDurationGestation) {
        this.currentDurationGestation = currentDurationGestation;
    }

    /**
     * Setter for property 'durationGestation'.
     *
     * @param durationGestation Value to set for property 'durationGestation'.
     */
    public void setDurationGestation(int durationGestation) {

        this.durationGestation = durationGestation;
    }

    /**
     * Getter for property 'height'.
     *
     * @return Value for property 'height'.
     */
    public int getHeight() {
        return this.height;
    }

    /**
     * Getter for property 'age'.
     *
     * @return Value for property 'age'.
     */
    public int getAge() {
        return this.age;
    }

    /**
     * Getter for property 'hungerIndicator'.
     *
     * @return Value for property 'hungerIndicator'.
     */
    public boolean getHungerIndicator() {
        return this.hungerIndicator;
    }

    /**
     * Getter for property 'sleepIndicator'.
     *
     * @return Value for property 'sleepIndicator'.
     */
    public boolean getSleepIndicator() {
        return this.sleepIndicator;
    }

    /**
     * Getter for property 'healthIndicator'.
     *
     * @return Value for property 'healthIndicator'.
     */
    public boolean getHealthIndicator() {
        return this.healthIndicator;
    }

    /**
     * Getter for property 'weight'.
     *
     * @return Value for property 'weight'.
     */
    public int getWeight() {
        return this.weight;
    }

    /**
     * Getter for property 'sex'.
     *
     * @return Value for property 'sex'.
     */
    public char getSex() {
        return this.sex;
    }

    /**
     * Getter for property 'name'.
     *
     * @return Value for property 'name'.
     */
    public String getName() {
        return this.name;
    }

    /**
     * Setter for property 'name'.
     *
     * @param name Value to set for property 'name'.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Setter for property 'sex'.
     *
     * @param sex Value to set for property 'sex'.
     */
    public void setSex(char sex) {
        this.sex = sex;
    }

    /**
     * Setter for property 'weight'.
     *
     * @param weight Value to set for property 'weight'.
     */
    public void setWeight(int weight) {
        this.weight = weight;
    }

    /**
     * Setter for property 'height'.
     *
     * @param height Value to set for property 'height'.
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * Setter for property 'age'.
     *
     * @param age Value to set for property 'age'.
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * Setter for property 'hungerIndicator'.
     *
     * @param hungerIndicator Value to set for property 'hungerIndicator'.
     */
    public void setHungerIndicator(boolean hungerIndicator) {
        this.hungerIndicator = hungerIndicator;
    }

    /**
     * Setter for property 'sleepIndicator'.
     *
     * @param sleepIndicator Value to set for property 'sleepIndicator'.
     */
    public void setSleepIndicator(boolean sleepIndicator) {
        this.sleepIndicator = sleepIndicator;
    }

    /**
     * Setter for property 'healthIndicator'.
     *
     * @param healthIndicator Value to set for property 'healthIndicator'.
     */
    public void setHealthIndicator(boolean healthIndicator) {
        this.healthIndicator = healthIndicator;
    }

    /** {@inheritDoc} */
    public void eat(int i) {
        if(!this.getSleepIndicator()) {
            if(!this.getHungerIndicator())
                this.getView().showNotHungry(this.getName() + " n°" + (i+1) + " ");
            else {
                this.setHungerIndicator(false);
                this.getView().showEat(this.getName() + " n°" + (i+1) + " ");
            }
        }
        else
            this.getView().showErrEat(this.getName());
    }

    /** {@inheritDoc} */
    public void makeSound() {

        this.getView().showMakeSoud(this.getName());
    }

    /** {@inheritDoc} */ //endormir ou reveiller
    public boolean changeCondition() {
        if(this.getSleepIndicator()) {//dort
            this.setSleepIndicator(false);
            return this.getSleepIndicator();
        }else {//eveillé
            this.setSleepIndicator(true);
            return this.getSleepIndicator();
        }
    }

    /** {@inheritDoc} */
    public void move() {
        this.getView().showMove(this.getName());
    }

    /** {@inheritDoc} */
    public void treat() {
        if(!this.getHealthIndicator()) {
            this.setHealthIndicator(true);
            this.getView().showTreat(this.getName());
        }
        else
            this.getView().showErrTreat();
    }

    /**
     * Getter for property 'view'.
     *
     * @return Value for property 'view'.
     */
    public ViewAnimal getView() {
        return this.view;
    }

    /** {@inheritDoc} */ //s'accoupler
    public void mate(Animal a) {
        if(!this.getClass().getSimpleName().equals(a.getClass().getSimpleName()))
            this.getView().showErrMate();
        else {
            if (this.isPregnant())
                this.getView().showErrMate1(this.getName());
            else if (a.isPregnant())
                this.getView().showErrMate1(a.getName());
            else if (this.getSex() == 'm' && a.getSex() == 'm' || this.getSex() == 'f' && this.getSex() == 'f')
                this.getView().showErrMate2();
            else if (this.getSleepIndicator() || a.getSleepIndicator())
                this.getView().showErrMate3(this.getName());
            else {
                if (this.getSex() == 'f')
                    this.setPregnant(true);
                else
                    a.setPregnant(true);
            }
        }
    }
}
