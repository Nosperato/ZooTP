package ZooTD;

/**
 * Created by d13002386 on 10/10/2016.
 */
public interface Flying {
    /**
     * Fly.
     */
    public void fly();
}
