package ZooTD;


/**
 * The type Mammal.
 */
public abstract class Mammal extends Animal implements MammalAction{
    /**
     * Getter for property 'viewMammal'.
     *
     * @return Value for property 'viewMammal'.
     */
    public ViewMammal getViewMammal() {
        return viewMammal;
    }

    /**
     * Setter for property 'viewMammal'.
     *
     * @param viewMammal Value to set for property 'viewMammal'.
     */
    public void setViewMammal(ViewMammal viewMammal) {
        this.viewMammal = viewMammal;
    }

    private ViewMammal viewMammal;

}
